package com.crud.crud_app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crud.crud_app.entity.EmpEntity;

public interface EmployeeRepository extends JpaRepository<EmpEntity, Long> {

}
