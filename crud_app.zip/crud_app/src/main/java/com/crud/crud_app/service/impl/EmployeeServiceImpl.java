package com.crud.crud_app.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.crud.crud_app.entity.EmpEntity;
import com.crud.crud_app.exception.ResourceNotFoundException;
import com.crud.crud_app.repository.EmployeeRepository;
import com.crud.crud_app.service.EmployeeService;

import jakarta.persistence.Id;


@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	//Constructor injection of repository layer since values are mandatory
	private EmployeeRepository employeereository;
	
	

	public EmployeeServiceImpl(EmployeeRepository employeereository) {
		super();
		this.employeereository = employeereository;
	}



	@Override
	public EmpEntity saveEmployee(EmpEntity employee) {
		return employeereository.save(employee);
	}
	
	//To fetch all employees
	@Override
	public List<EmpEntity> getAllEmployees() {
		return employeereository.findAll();
	}
	
	//To fetch particular employee
	@Override
	public EmpEntity getEmployeeById(long id) {
//		Optional<EmpEntity> empEntity = employeereository.findById(id);
//		if(empEntity.isPresent()) {
//			return empEntity.get();
//		}else {
//			throw new ResourceNotFoundException("EmpEntity","Id", id);
//		}
		
		return employeereository.findById(id).orElseThrow(() -> new ResourceNotFoundException("EmpEntity", "Id",id));
	}
	
	
	//Updating Employee Rest api details
	@Override
	public EmpEntity updateEmloyee(EmpEntity empEntity, long id) {
		//we need to check whether a emp with given id is in Db or not
		EmpEntity existingEmployee = employeereository.findById(id).orElseThrow(()-> new ResourceNotFoundException("EmpEntity", "Id", id));
		
		existingEmployee.setEmpname(empEntity.getEmpname());
		existingEmployee.setEmpPhno(empEntity.getEmpPhno());
		existingEmployee.setEmpSalary(empEntity.getEmpSalary());
		//Saving existing employee to DB
		employeereository.save(existingEmployee);
		return existingEmployee;
	}
	
	
	//Deleting Employee Rest Api
	
	@Override
	public void deleteEmployee(long id) {
		
		//check employee is in DB or not
		employeereository.findById(id).orElseThrow(() -> new ResourceNotFoundException("EmpEntity","Id", id));
		
		employeereository.deleteById(id);
		
	}
	
	
	
	

}
