package com.crud.crud_app.service;

import java.util.List;

import com.crud.crud_app.entity.EmpEntity;

public interface EmployeeService {
	
	EmpEntity saveEmployee(EmpEntity employee);
	
	List<EmpEntity>getAllEmployees();
	
	EmpEntity getEmployeeById(long id);
	
	EmpEntity updateEmloyee(EmpEntity empEntity, long id);
	
	void deleteEmployee(long id);

}
