package com.crud.crud_app.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Emloyee")
public class EmpEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long empId;
	
	@Column(name = "Employee_name")
	private String Empname;
	
	@Column(name = "Employee_Phone_Number")
	private String EmpPhno;
	
	@Column(name="Employee_Salary")
	private double EmpSalary;

	public EmpEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmpEntity(long empId, String empname, String empPhno, double empSalary) {
		super();
		this.empId = empId;
		Empname = empname;
		EmpPhno = empPhno;
		EmpSalary = empSalary;
	}

	public long getEmpId() {
		return empId;
	}

	public String getEmpname() {
		return Empname;
	}

	public String getEmpPhno() {
		return EmpPhno;
	}

	public double getEmpSalary() {
		return EmpSalary;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}

	public void setEmpname(String empname) {
		Empname = empname;
	}

	public void setEmpPhno(String empPhno) {
		EmpPhno = empPhno;
	}

	public void setEmpSalary(double empSalary) {
		EmpSalary = empSalary;
	}

	@Override
	public String toString() {
		return "EmpEntity [empId=" + empId + ", Empname=" + Empname + ", EmpPhno=" + EmpPhno + ", EmpSalary="
				+ EmpSalary + "]";
	}
	
	

}
