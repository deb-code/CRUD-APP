package com.crud.crud_app.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crud.crud_app.entity.EmpEntity;
import com.crud.crud_app.service.EmployeeService;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
	
	private EmployeeService employeeService;

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	
	//Building Employee Rest Api
	@PostMapping()
	public ResponseEntity<EmpEntity>saveEmployee(@RequestBody EmpEntity employee){
		return new ResponseEntity<EmpEntity>(employeeService.saveEmployee(employee), HttpStatus.CREATED);
		
	}
	
	//Build get for all employees
	@GetMapping
	public List<EmpEntity> getAllEmployees(){
		return employeeService.getAllEmployees();
	}
	
	//Build get employee Rest api's by id's
	//http://localhost:8082/api/employees/1
	@GetMapping("{id}")
	public ResponseEntity<EmpEntity> getEmployeeId(@PathVariable("id") long id){
		return new ResponseEntity<EmpEntity>(employeeService.getEmployeeById(id), HttpStatus.OK);
		
	}
	
	 //build update employee Rest Api
	@PutMapping("{id}")
	public ResponseEntity<EmpEntity>updateEmployee(@PathVariable("id")long id,@RequestBody EmpEntity empEntity){
		return new ResponseEntity<EmpEntity>(employeeService.updateEmloyee(empEntity, id), HttpStatus.OK);
		
	}
	
	//build delete api rest api
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("id") long id){
		//delete anyone from DB
		employeeService.deleteEmployee(id);
		
		return new ResponseEntity<String>("Employee deleted successfully!", HttpStatus.OK );
		
	}

}
