package com.crud.crud_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
